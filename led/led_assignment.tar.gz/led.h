#ifndef LED_H
#define LED_H

#define GPIO_LED_OFF    0
#define GPIO_LED_ON     1

#define GPIO_LED_0      21

#define GPIO_BUTTON_0	26

#endif